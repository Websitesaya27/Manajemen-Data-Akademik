<?php

session_start();

// Mengecek apakah pengguna sudah login
if (!isset($_SESSION['ssLogin'])) {
    header("location:../auth/login.php");
    exit;
}

// Menghubungkan ke file konfigurasi untuk koneksi database
require_once "../config.php";

// Proses penyimpanan data dosen baru
if (isset($_POST['simpan'])) {
    $nip = htmlspecialchars($_POST['nip']);
    $nama = htmlspecialchars($_POST['nama']);
    $telephone = htmlspecialchars($_POST['telephone']);
    $agama = $_POST['agama'];
    $alamat = htmlspecialchars($_POST['alamat']);
    $foto = htmlspecialchars($_FILES['image']['name']);

    // Mengecek apakah NIP sudah ada di database
    $cekNip = mysqli_query($koneksi, "SELECT nip FROM tbl_dosen WHERE nip = '$nip'");
    if (mysqli_num_rows($cekNip) > 0) {
        header('location:add-dosen.php?msg=cancel');
        return;
    }

    // Jika ada foto yang diupload, proses upload
    if ($foto != null) {
        $url = "add-dosen.php";
        $foto = uploadimg($url);
    } else {
        $foto = 'default.png';
    }

    // Menyimpan data dosen ke dalam database
    mysqli_query($koneksi, "INSERT INTO tbl_dosen VALUES(null, '$nip', '$nama', '$alamat', '$telephone', '$agama', '$foto')");

    // Mengarahkan kembali ke halaman tambah dosen dengan pesan sukses
    header("location:add-dosen.php?msg=added");
    return;
}

// Proses pembaruan data dosen
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $nip = htmlspecialchars($_POST['nip']);
    $nama = htmlspecialchars($_POST['nama']);
    $telephone = htmlspecialchars($_POST['telephone']);
    $agama = $_POST['agama'];
    $alamat = htmlspecialchars($_POST['alamat']);
    $foto = htmlspecialchars($_POST['fotoLama']);

    // Mendapatkan data dosen berdasarkan ID
    $sqlDosen = mysqli_query($koneksi, "SELECT * FROM tbl_dosen WHERE id = $id");
    $data = mysqli_fetch_array($sqlDosen);
    $curNIP = $data['nip'];

    // Mengecek apakah NIP baru sudah ada di database
    $newNIP = mysqli_query($koneksi, "SELECT nip FROM tbl_dosen WHERE nip = '$nip'");

    // Jika NIP yang diupdate berbeda dengan NIP yang lama
    if ($nip !== $curNIP) {
        if (mysqli_num_rows($newNIP) > 0) {
            header("location:dosen.php?msg=cancel");
            return;
        }
    }

    // Mengecek apakah ada file foto baru yang diupload
    if ($_FILES['image']['error'] === 4) {
        $fotoDosen = $foto;
    } else {
        $url = "dosen.php";
        $fotoDosen = uploadimg($url);
        // Menghapus foto lama jika bukan foto default
        if ($foto !== 'default.png') {
            @unlink('../asset/image/' . $foto);
        }
    }

    // Memperbarui data dosen di dalam database
    mysqli_query($koneksi, "UPDATE tbl_dosen SET
                            nip = '$nip',
                            nama = '$nama',
                            telephone = '$telephone',
                            agama = '$agama',
                            alamat = '$alamat',
                            foto = '$fotoDosen'
                            WHERE id = $id
                            ");

    // Mengarahkan kembali ke halaman dosen dengan pesan sukses
    header("location:dosen.php?msg=updated");
    return;
}

?>
