<?php

// Memulai sesi
session_start();

// Mengecek apakah pengguna sudah login
if (!isset($_SESSION['ssLogin'])) {
    // Jika belum login, alihkan ke halaman login
    header("location:../auth/login.php");
    exit();
}

// Menghubungkan ke file konfigurasi untuk koneksi database
require_once "../config.php";

// Mengambil ID dosen dan nama file foto dari parameter URL
$id = $_GET["id"];
$foto = $_GET["foto"];

// Menghapus data dosen dari tabel 'tbl_dosen' berdasarkan ID
mysqli_query($koneksi, "DELETE FROM tbl_dosen WHERE id= $id");

// Mengecek apakah foto yang dihapus bukan foto default
if ($foto != 'default.png') {
    // Menghapus file foto dari folder asset/image/
    unlink("../asset/image/" . $foto);
}

// Mengarahkan kembali ke halaman 'dosen.php' dengan pesan bahwa data dosen telah dihapus
header("location:dosen.php?msg=deleted");

?>
