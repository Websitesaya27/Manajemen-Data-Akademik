<?php

session_start();

// Mengecek apakah pengguna sudah login
if (!isset($_SESSION["ssLogin"])) {
    header("location:../auth/login.php");
    exit();
}

// Menghubungkan ke file konfigurasi untuk koneksi database
require_once "../config.php";

// Mengatur judul halaman dan menyertakan template header, navbar, dan sidebar
$title = "Mata Pelajaran - Politeknik LP3I";
require_once "../template/header.php";
require_once "../template/navbar.php";
require_once "../template/sidebar.php";

// Mendapatkan ID mata pelajaran dari parameter URL
$id = $_GET['id'];

// Mengambil data mata pelajaran dari database berdasarkan ID
$queryPelajaran = mysqli_query($koneksi, "SELECT * FROM tbl_pelajaran WHERE id = $id");
$data = mysqli_fetch_array($queryPelajaran);
?>

<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Update Mata Pelajaran</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="pelajaran.php">Back</a></li>
            </ol>
            <div class="row">
                <div class="col-4">
                    <div class="card">
                        <div class="card-header">
                            <i class="fa-solid fa-pen"></i> Edit Pelajaran
                        </div>
                        <div class="card-body">
                            <!-- Form untuk mengupdate data mata pelajaran -->
                            <form action="proses-pelajaran.php" method="POST">
                                <input type="number" name="id" value="<?= $data['id'] ?>" hidden>
                                <div class="mb-3">
                                    <label for="pelajaran" class="form-label ps-1">Pelajaran</label>
                                    <input type="text" class="form-control" id="pelajaran" name="pelajaran" placeholder="nama pelajaran" value="<?= $data['pelajaran'] ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="jurusan" class="form-label ps-1">Jurusan</label>
                                    <select name="jurusan" id="jurusan" class="form-select" required>
                                        <?php 
                                        // Menampilkan pilihan jurusan
                                        $jurusan = ["Administrasi Bisnis Internasional", "Administrasi Bisnis", "Manajemen Informatika", "Komputerisasi Akuntansi"];
                                        foreach ($jurusan as $jrs) {
                                            if ($data['jurusan'] == $jrs) { ?>
                                                <option value="<?= $jrs ?>" selected><?= $jrs ?></option>
                                            <?php } else { ?>
                                                <option value="<?= $jrs ?>"><?= $jrs ?></option>
                                            <?php }
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="dosen" class="form-label ps-1">Dosen</label>
                                    <select name="dosen" id="dosen" class="form-select" required>
                                        <?php
                                        // Menampilkan pilihan dosen
                                        $queryDosen = mysqli_query($koneksi, "SELECT * FROM tbl_dosen");
                                        while ($dataDosen = mysqli_fetch_array($queryDosen)) {
                                            if ($data['dosen'] == $dataDosen['nama']) { ?>
                                                <option value="<?= $dataDosen['nama'] ?>" selected><?= $dataDosen['nama'] ?></option>
                                            <?php } else { ?>
                                                <option value="<?= $dataDosen['nama'] ?>"><?= $dataDosen['nama'] ?></option>
                                            <?php }
                                        }
                                        ?>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-primary" name="update"><i class="fa-solid fa-pen"></i> Update</button>
                                <a href="pelajaran.php" class="btn btn-danger"><i class="fa-solid fa-xmark"></i> Cancel</a>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-8">
                    <div class="card">
                        <div class="card-header">
                            <i class="fa-solid fa-list"></i> Data Pelajaran
                        </div>
                        <div class="card-body">
                            <!-- Tabel untuk menampilkan data mata pelajaran -->
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col"><center>Mata Pelajaran</center></th>
                                        <th scope="col"><center>Jurusan</center></th>
                                        <th scope="col"><center>Dosen</center></th>
                                        <th scope="col"><center>Operasi</center></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = 1;
                                    ?>
                                    <tr>
                                        <th scope="row"><?= $no ?></th>
                                        <td><?= $data['pelajaran'] ?></td>
                                        <td><?= $data['jurusan'] ?></td>
                                        <td><?= $data['dosen'] ?></td>
                                        <td align="center">
                                           <button type="button" class="btn btn-sm btn-warning rounded-0 col-10">Updating...</button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

<?php
// Menyertakan template footer
require_once "../template/footer.php";
?>
