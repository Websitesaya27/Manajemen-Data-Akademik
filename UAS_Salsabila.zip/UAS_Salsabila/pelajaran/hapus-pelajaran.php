<?php

session_start();

// Mengecek apakah pengguna sudah login
if (!isset($_SESSION['ssLogin'])) {
    header("location:../auth/login.php");
    exit();
}

// Menghubungkan ke file konfigurasi untuk koneksi database
require_once "../config.php";

// Mendapatkan ID mata pelajaran dari parameter URL
$id = $_GET['id'];

// Menghapus data mata pelajaran dari database berdasarkan ID
mysqli_query($koneksi, "DELETE FROM tbl_pelajaran WHERE id = $id");

// Mengarahkan pengguna kembali ke halaman pelajaran dengan pesan sukses
header("location:pelajaran.php?msg=deleted");

?>
