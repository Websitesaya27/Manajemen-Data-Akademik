<?php

session_start();

// Mengecek apakah pengguna sudah login
if (!isset($_SESSION['ssLogin'])) {
    header("location:../auth/login.php");
    exit();
}

// Menghubungkan ke file konfigurasi untuk koneksi database
require_once "../config.php";

// Proses tambah pelajaran
if (isset($_POST['simpan'])) {
    // Mengambil data dari form dan mengamankan input dengan htmlspecialchars
    $pelajaran = htmlspecialchars($_POST['pelajaran']);
    $jurusan = $_POST['jurusan'];
    $dosen = $_POST['dosen'];

    // Mengecek apakah pelajaran sudah ada di database
    $cekPelajaran = mysqli_query($koneksi, "SELECT * FROM tbl_pelajaran WHERE pelajaran = '$pelajaran'");
    if (mysqli_num_rows($cekPelajaran) > 0) {
        header("location:pelajaran.php?msg=cancel");
        return;
    }

    // Menyimpan data pelajaran baru ke database
    mysqli_query($koneksi, "INSERT INTO tbl_pelajaran VALUES (null, '$pelajaran', '$jurusan', '$dosen')");
    header("location:pelajaran.php?msg=added");
    return;
}

// Proses update pelajaran
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $pelajaran = htmlspecialchars($_POST['pelajaran']);
    $jurusan = $_POST['jurusan'];
    $dosen = $_POST['dosen'];

    // Mengambil data pelajaran yang akan diupdate
    $queryPelajaran = mysqli_query($koneksi, "SELECT * FROM tbl_pelajaran WHERE id = $id");
    $data = mysqli_fetch_array($queryPelajaran);
    $curPelajaran = $data['pelajaran'];

    // Mengecek apakah pelajaran baru sudah ada di database
    $cekPelajaran = mysqli_query($koneksi, "SELECT * FROM tbl_pelajaran WHERE pelajaran = '$pelajaran'");

    if ($pelajaran !== $curPelajaran) {
        if (mysqli_num_rows($cekPelajaran) > 0) {
            header("location:pelajaran.php?msg=cancelupdate");
            return;
        }
    }

    // Mengupdate data pelajaran di database
    mysqli_query($koneksi, "UPDATE tbl_pelajaran SET pelajaran = '$pelajaran', jurusan = '$jurusan', dosen = '$dosen' WHERE id = $id");

    header("location:pelajaran.php?msg=updated");
    return;
}

?>
