<?php

// Memulai sesi PHP
session_start();

// Memeriksa apakah pengguna sudah login, jika tidak maka arahkan ke halaman login
if (!isset($_SESSION["ssLogin"])) {
    header("location:../auth/login.php");
    exit;
}

// Menghubungkan ke konfigurasi database
require_once "../config.php";

// Menetapkan judul halaman
$title = "Tambah Siswa - Politeknik LP3I";

// Memuat template header, navbar, dan sidebar
require_once "../template/header.php";
require_once "../template/navbar.php";
require_once "../template/sidebar.php";

// Mengambil NISN tertinggi dari tabel siswa untuk menentukan NISN berikutnya
$queryNisn = mysqli_query($koneksi, "SELECT max(nisn) as maxnisn FROM tbl_siswa");
$data = mysqli_fetch_array($queryNisn);
$maxnisn = $data["maxnisn"];

// Mengambil nomor urut dari NISN yang tertinggi dan menambahkannya untuk membuat NISN baru
$noUrut = (int) substr($maxnisn, 3, 3);
$noUrut++;
$maxnisn = "NISN".sprintf("%03s", $noUrut);

?>

<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <!-- Judul Halaman -->
            <h1 class="mt-4">Tambah Siswa</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="siswa.php">Siswa</a></li>
                <li class="breadcrumb-item active">Tambah Siswa</li>
            </ol>
            <!-- Formulir untuk menambah siswa -->
            <form action="proses-siswa.php" method="POST" enctype="multipart/form-data">
                <div class="card">
                    <div class="card-header">
                        <span class="h5 my-2"><i class="fa-solid fa-square-plus"></i> Tambah Siswa</span>
                        <!-- Tombol Simpan untuk mengirimkan data formulir -->
                        <button type="submit" name="simpan" class="btn btn-primary float-end"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
                        <!-- Tombol Reset untuk mengatur ulang data formulir -->
                        <button type="reset" name="reset" class="btn btn-danger float-end me-1"><i class="fa-solid fa-xmark"></i> Reset</button>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8">
                                <!-- Input NISN untuk siswa baru, sudah otomatis diisi dengan NISN terbaru -->
                                <div class="mb-3 row">
                                    <label for="nisn" class="col-sm-2 col-form-label">NISN</label>
                                    <label for="nisn" class="col-sm-1 col-form-label">:</label>
                                    <div class="col-sm-9" style="margin-left: -50px;">
                                        <input type="text" name="nisn" class="form-control border-0 border-bottom ps-2" id="nisn" value="<?= $maxnisn ?>">
                                    </div>
                                </div>
                                <!-- Input Nama siswa -->
                                <div class="mb-3 row">
                                    <label for="nama" class="col-sm-2 col-form-label">Nama</label>
                                    <label for="nama" class="col-sm-1 col-form-label">:</label>
                                    <div class="col-sm-9" style="margin-left: -50px;">
                                        <input type="text" name="nama" class="form-control border-0 border-bottom ps-2" id="nama" required>
                                    </div>
                                </div>
                                <!-- Dropdown untuk memilih kelas siswa -->
                                <div class="mb-3 row">
                                    <label for="kelas" class="col-sm-2 col-form-label">Kelas</label>
                                    <label for="kelas" class="col-sm-1 col-form-label">:</label>
                                    <div class="col-sm-9" style="margin-left: -50px;">
                                        <select name="kelas" class="form-select border-0 border-bottom" id="kelas" required>
                                            <option selected>--Pilih Kelas--</option>
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                        </select>
                                    </div>
                                </div>
                                <!-- Dropdown untuk memilih jurusan siswa -->
                                <div class="mb-3 row">
                                    <label for="jurusan" class="col-sm-2 col-form-label">Jurusan</label>
                                    <label for="jurusan" class="col-sm-1 col-form-label">:</label>
                                    <div class="col-sm-9" style="margin-left: -50px;">
                                        <select name="jurusan" class="form-select border-0 border-bottom" id="jurusan" required>
                                            <option selected>--Pilih Jurusan--</option>
                                            <option value="abi">Administrasi Bisnis Internasional</option>
                                            <option value="ab">Administrasi Bisnis</option>
                                            <option value="mi">Manajemen Informatika</option>
                                            <option value="ka">Komputerisasi Akutansi</option>
                                        </select>
                                    </div>
                                </div>
                                <!-- Textarea untuk memasukkan alamat siswa -->
                                <div class="mb-3 row">
                                    <label for="alamat" class="col-sm-2 col-form-label">Alamat</label>
                                    <label for="alamat" class="col-sm-1 col-form-label">:</label>
                                    <div class="col-sm-9" style="margin-left: -50px;">
                                        <textarea name="alamat" id="alamat" cols="30" rows="3" placeholder="alamat siswa" class="form-control" required></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="col-4 text-center px-5">
                                <!-- Gambar default untuk siswa -->
                                <img src="../asset/image/default.png" class="mb-3" width="40%" alt="">
                                <!-- Input file untuk mengupload foto siswa -->
                                <input type="file" name="image" class="form-control form-control-sm">
                                <small class="text-secondary">Pilih foto PNG, JPG, atau JPEG dengan ukuran maksimal 1 MB</small>
                                <div><small class="text-secondary">width = height</small></div>
                            </div>
                        </div>    
                    </div>
                </div>
            </form>
        </div>
    </main>

<?php

// Memuat template footer
require_once "../template/footer.php";
?>
