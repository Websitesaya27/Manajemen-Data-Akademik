<?php

// Memulai sesi PHP
session_start();

// Memeriksa apakah pengguna sudah login, jika tidak maka arahkan ke halaman login
if (!isset($_SESSION['ssLogin'])) {
    header("location:../auth/login.php");
    exit;
}

// Menghubungkan ke konfigurasi database
require_once "../config.php";

// Menetapkan judul halaman
$title = "Update Siswa - Politeknik LP3I";

// Memuat template header, navbar, dan sidebar
require_once "../template/header.php";
require_once "../template/navbar.php";
require_once "../template/sidebar.php";

// Mengambil parameter 'nisn' dari URL
$nisn = $_GET['nisn'];

// Mengambil data siswa berdasarkan NISN
$siswa = mysqli_query($koneksi, "SELECT * FROM tbl_siswa WHERE nisn = '$nisn'");
$data = mysqli_fetch_array($siswa);

?>

<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <!-- Judul Halaman -->
            <h1 class="mt-4">Update Siswa</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="siswa.php">Siswa</a></li>
                <li class="breadcrumb-item active">Update Siswa</li>
            </ol>
            <!-- Formulir untuk memperbarui data siswa -->
            <form action="proses-siswa.php" method="POST" enctype="multipart/form-data">
                <div class="card">
                    <div class="card-header">
                        <span class="h5 my-2"><i class="fa-solid fa-pen-to-square"></i> Update Siswa</span>
                        <!-- Tombol Update untuk mengirimkan data formulir -->
                        <button type="submit" name="update" class="btn btn-primary float-end"><i class="fa-solid fa-floppy-disk"></i> Update</button>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8">
                                <!-- Hidden field untuk ID siswa -->
                                <input type="hidden" name="id" value="<?= $data['id'] ?>">
                                
                                <!-- Field NISN siswa, hanya untuk ditampilkan -->
                                <div class="mb-3 row">
                                    <label for="nisn" class="col-sm-2 col-form-label">NISN</label>
                                    <label for="nisn" class="col-sm-1 col-form-label">:</label>
                                    <div class="col-sm-9" style="margin-left: -50px;">
                                        <input type="text" name="nisn" class="form-control-plaintext border-bottom ps-2" id="nisn" value="<?= $nisn ?>" required>
                                    </div>
                                </div>
                                <!-- Field Nama siswa yang akan diperbarui -->
                                <div class="mb-3 row">
                                    <label for="nama" class="col-sm-2 col-form-label">Nama</label>
                                    <label for="nama" class="col-sm-1 col-form-label">:</label>
                                    <div class="col-sm-9" style="margin-left: -50px;">
                                        <input type="text" name="nama" class="form-control border-0 border-bottom ps-2" id="nama" value="<?= $data['nama'] ?>" required>
                                    </div>
                                </div>
                                <!-- Dropdown untuk memilih kelas siswa -->
                                <div class="mb-3 row">
                                    <label for="kelas" class="col-sm-2 col-form-label">Kelas</label>
                                    <label for="kelas" class="col-sm-1 col-form-label">:</label>
                                    <div class="col-sm-9" style="margin-left: -50px;">
                                        <select name="kelas" id="kelas" class="form-select border-0 border-bottom" required>
                                            <?php
                                            $kelas = ['1', '2', '3'];
                                            foreach ($kelas as $kls) {
                                                if ($data['kelas'] == $kls) { ?>
                                                    <option value="<?= $kls; ?>" selected><?= $kls; ?></option>
                                                <?php } else { ?>
                                                    <option value="<?= $kls; ?>"><?= $kls; ?></option>
                                                <?php 
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <!-- Dropdown untuk memilih jurusan siswa -->
                                <div class="mb-3 row">
                                    <label for="jurusan" class="col-sm-2 col-form-label">Jurusan</label>
                                    <label for="jurusan" class="col-sm-1 col-form-label">:</label>
                                    <div class="col-sm-9" style="margin-left: -50px;">
                                        <select name="jurusan" id="jurusan" class="form-select border-0 border-bottom" required>
                                            <?php
                                            $jurusan = ["Administrasi Bisnis Internasional", "Administrasi Bisnis", "Manajemen Informatika", "Komputerisasi Akutansi"];
                                            foreach($jurusan as $jrs) {
                                                if ($data['jurusan'] == $jrs) { ?>
                                                    <option value="<?= $jrs ?>" selected><?= $jrs ?></option>
                                                <?php } else { ?>
                                                    <option value="<?= $jrs ?>"><?= $jrs ?></option>
                                                <?php }
                                            } ?>
                                        </select>
                                    </div>
                                </div>
                                <!-- Textarea untuk memperbarui alamat siswa -->
                                <div class="mb-3 row">
                                    <label for="alamat" class="col-sm-2 col-form-label">Alamat</label>
                                    <label for="alamat" class="col-sm-1 col-form-label">:</label>
                                    <div class="col-sm-9" style="margin-left: -50px;">
                                        <textarea name="alamat" id="alamat" cols="30" rows="3" class="form-control" required><?= $data['alamat'] ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="col-4 text-center px-5">
                                <!-- Hidden field untuk menyimpan foto lama -->
                                <input type="hidden" name="fotoLama" value="<?= $data['foto'] ?>">
                                <!-- Menampilkan foto siswa saat ini -->
                                <img src="../asset/image/<?= $data['foto'] ?>" class="mb-3 rounded-circle" width="40%" alt="">
                                <!-- Input file untuk mengupload foto baru siswa -->
                                <input type="file" name="image" class="form-control form-control-sm">
                                <small class="text-secondary">Pilih foto PNG, JPG, atau JPEG dengan ukuran maksimal 1 MB</small>
                                <div><small class="text-secondary">width = height</small></div>
                            </div>
                        </div>    
                    </div>
                </div>
            </form>
        </div>
    </main>

<?php

// Memuat template footer
require_once "../template/footer.php";
?>
