<?php

// Memulai sesi PHP untuk melacak status login pengguna
session_start();

// Memeriksa apakah pengguna sudah login, jika tidak maka arahkan ke halaman login
if (!isset($_SESSION["ssLogin"])) {
    header("location: ../auth/login.php");
    exit();
}

// Menghubungkan ke konfigurasi database
require_once "../config.php";

// Menangani form simpan data siswa
if (isset($_POST['simpan'])) {
    // Mengambil data dari form dan membersihkan input
    $nisn = mysqli_real_escape_string($koneksi, $_POST['nisn']);
    $nama = htmlspecialchars($_POST['nama']);
    $kelas = mysqli_real_escape_string($koneksi, $_POST['kelas']);
    $jurusan = mysqli_real_escape_string($koneksi, $_POST['jurusan']);
    $alamat = htmlspecialchars($_POST['alamat']);
    $foto = htmlspecialchars($_FILES['image']['name']);

    // Cek apakah NISN sudah ada di database
    $cekNisn = mysqli_query($koneksi, "SELECT * FROM tbl_siswa WHERE nisn = '$nisn'");
    if (mysqli_num_rows($cekNisn) > 0) {
        echo "<script>
                alert('NISN sudah ada, gunakan NISN lain');
                document.location.href = 'add-siswa.php';
              </script>";
        return;
    }

    error_log("NISN yang diterima: " . $nisn);

    // Jika ada file foto, upload foto baru
    if ($foto != null) {
        $url = "add-siswa.php";
        $foto = uploadimg($url);
    } else {
        $foto = 'default.png';
    }

    // Menyimpan data siswa ke database
    $query = "INSERT INTO tbl_siswa (nisn, nama, alamat, kelas, jurusan, foto) VALUES ('$nisn', '$nama', '$alamat', '$kelas', '$jurusan', '$foto')";
    if (mysqli_query($koneksi, $query)) {
        echo "<script>
                alert('Data siswa berhasil disimpan');
                document.location.href = 'siswa.php';
              </script>";
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
    }
    return;
    
} else if (isset($_POST['update'])) {
    // Mengambil data dari form dan membersihkan input
    $nisn = mysqli_real_escape_string($koneksi, $_POST['nisn']);
    $nama = htmlspecialchars($_POST['nama']);
    $kelas = mysqli_real_escape_string($koneksi, $_POST['kelas']);
    $jurusan = mysqli_real_escape_string($koneksi, $_POST['jurusan']);
    $alamat = htmlspecialchars($_POST['alamat']);
    $foto = htmlspecialchars($_POST['fotoLama']);

    // Jika ada file foto yang diupload
    if ($_FILES['image']['error'] === 4) {
        $fotoSiswa = $foto; // Gunakan foto lama
    } else {
        $url = "siswa.php";
        $fotoSiswa = uploadimg($url); // Upload foto baru
        if ($foto != 'default.png') {
            @unlink('../asset/image/' . $foto); // Hapus foto lama jika bukan foto default
        }
    }

    // Mengupdate data siswa di database
    $query = "UPDATE tbl_siswa SET
                nama = '$nama',
                kelas = '$kelas',
                jurusan = '$jurusan',
                alamat = '$alamat',
                foto = '$fotoSiswa'
              WHERE nisn = '$nisn'";
    
    if (mysqli_query($koneksi, $query)) {
        echo "<script>
                alert('Data siswa berhasil di update');
                document.location.href='siswa.php';
              </script>";
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
    }
    return;
}

?>
