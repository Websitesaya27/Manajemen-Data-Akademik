<?php

// Memulai sesi PHP untuk melacak status login pengguna
session_start();

// Memeriksa apakah pengguna sudah login, jika tidak maka arahkan ke halaman login
if (!isset($_SESSION['ssLogin'])) {
    header("location:../auth/login.php");
    exit();
}

// Menghubungkan ke konfigurasi database
require_once "../config.php";

// Mengambil parameter 'nisn' dan 'foto' dari URL
$id = $_GET['nisn'];
$foto = $_GET['foto'];

// Menghapus data siswa berdasarkan NISN dari database
mysqli_query($koneksi, "DELETE FROM tbl_siswa WHERE nisn = '$id'");

// Jika foto yang diupload bukan foto default, maka hapus file foto dari server
if ($foto != 'default.png') {
    unlink('../asset/image/' . $foto);
}

// Menampilkan pesan alert bahwa data siswa berhasil dihapus dan mengarahkan kembali ke halaman siswa.php
echo "<script>
        alert('Data siswa berhasil dihapus..');
        document.location.href='siswa.php';
    </script>";

// Menghentikan eksekusi script lebih lanjut
return;

?>
