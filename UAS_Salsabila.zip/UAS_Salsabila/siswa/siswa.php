<?php

// Memulai sesi PHP untuk melacak status login pengguna
session_start();

// Memeriksa apakah pengguna sudah login, jika tidak maka arahkan ke halaman login
if (!isset($_SESSION["ssLogin"])) {
    header("location:../auth/login.php");
    exit();
}

// Menghubungkan ke konfigurasi database
require_once "../config.php";
$title = "Siswa - Politeknik LP3I";
require_once "../template/header.php"; // Memuat header dari template
require_once "../template/navbar.php"; // Memuat navbar dari template
require_once "../template/sidebar.php"; // Memuat sidebar dari template

?>

<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Siswa</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                <li class="breadcrumb-item active">Siswa</li>
            </ol>
            <div class="card">
                <div class="card-header">
                    <span class="h5 my-2"><i class="fa-solid fa-list"></i> Data Siswa</span>
                    <!-- Tombol untuk menambah data siswa baru -->
                    <a href="<?= $main_url ?>siswa/add-siswa.php" class="btn btn-sm btn-primary float-end"><i class="fa-solid fa-plus"></i> Tambah Siswa</a>
                </div>
                <div class="card-body">
                    <!-- Tabel yang menampilkan data siswa -->
                    <table class="table table-hover" id="datatablesSimple">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col"><center>Foto</center></th>
                                <th scope="col"><center>NISN</center></th>
                                <th scope="col"><center>Nama</center></th>
                                <th scope="col"><center>Kelas</center></th>
                                <th scope="col"><center>Jurusan</center></th>
                                <th scope="col"><center>Alamat</center></th>
                                <th scope="col"><center>Operasi</center></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1; // Inisialisasi nomor urut
                            $querySiswa = mysqli_query($koneksi, "SELECT * FROM tbl_siswa"); // Query untuk mengambil data siswa dari database
                            while ($data = mysqli_fetch_array($querySiswa)) { ?>
                            
                            <tr>
                                <th scope="row"><?= $no++ ?></th> <!-- Menampilkan nomor urut siswa -->
                                <td align="center"><img src="../asset/image/<?= $data['foto'] ?>" class="rounded-circle" alt="foto siswa" width="60px"></td> <!-- Menampilkan foto siswa -->
                                <td><?= $data['nisn'] ?></td> <!-- Menampilkan NISN siswa -->
                                <td><?= $data['nama'] ?></td> <!-- Menampilkan nama siswa -->
                                <td><?= $data['kelas'] ?></td> <!-- Menampilkan kelas siswa -->
                                <td><?= $data['jurusan'] ?></td> <!-- Menampilkan jurusan siswa -->
                                <td><?= $data['alamat'] ?></td> <!-- Menampilkan alamat siswa -->
                                <td align="center">
                                    <!-- Link untuk mengedit data siswa -->
                                    <a href="edit-siswa.php?nisn=<?= $data['nisn'] ?>" class="btn btn-sm btn-warning" title="Update Siswa"><i class="fa-solid fa-pen"></i></a>
                                    <!-- Tombol untuk menghapus data siswa dengan modal konfirmasi -->
                                    <button type="button" id="btnHapus" class="btn btn-sm btn-danger" title="hapussiswa" data-id="<?= $data['nisn'] ?>" data-foto="<?= $data['foto'] ?>"><i class="fa-solid fa-trash"></i></button>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <!-- Modal konfirmasi hapus data siswa -->
    <div class="modal fade" id="mdlHapus" tabindex="-1" data-bs-backdrop="static" aria-labelledby="mdlHapusLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Konfirmasi</h5> <!-- Judul modal -->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> <!-- Tombol untuk menutup modal -->
                </div>
                <div class="modal-body">
                    <p>Anda yakin akan menghapus data ini?</p> <!-- Pesan konfirmasi hapus -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button> <!-- Tombol untuk membatalkan hapus -->
                    <a href="#" id="btnMdlHapus" class="btn btn-danger">Ya</a> <!-- Tombol untuk mengkonfirmasi hapus -->
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function(){
            // Menangani klik pada tombol hapus
            $(document).on('click', "#btnHapus", function(){
                $('#mdlHapus').modal('show'); // Menampilkan modal konfirmasi hapus
                let idSiswa = $(this).data('id'); // Mengambil ID siswa dari atribut data-id
                let fotoSiswa = $(this).data('foto'); // Mengambil foto siswa dari atribut data-foto
                $('#btnMdlHapus').attr("href", "hapus-siswa.php?nisn=" + idSiswa + "&foto=" + fotoSiswa); // Menetapkan URL hapus pada tombol konfirmasi modal
            });
        });
    </script>

<?php

require_once "../template/footer.php"; // Memuat footer dari template

?>
