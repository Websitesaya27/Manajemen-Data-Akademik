<?php
session_start();

// Mengecek apakah pengguna sudah login
if (!isset($_SESSION['ssLogin'])) {
    header("location:../auth/login.php");
    exit();
}

// Menghubungkan ke file konfigurasi untuk koneksi database
require_once "../config.php";
require_once "proses-ekstrakurikuler.php";

// Mengambil ID ekstrakurikuler dari parameter URL
$id = $_GET['id'];
// Mengambil data ekstrakurikuler berdasarkan ID
$ekstrakurikuler = getExtracurricularById($id);

// Menetapkan judul halaman
$title = "Edit Ekstrakurikuler - Politeknik LP3I";
// Menghubungkan header, navbar, dan sidebar
require_once "../template/header.php";
require_once "../template/navbar.php";
require_once "../template/sidebar.php";
?>

<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Edit Ekstrakurikuler</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="ekstrakurikuler.php">Ekstrakurikuler</a></li>
                <li class="breadcrumb-item active">Edit Ekstrakurikuler</li>
            </ol>

            <!-- Card untuk menampilkan form edit ekstrakurikuler -->
            <div class="card mb-4">
                <div class="card-header">
                    Form Edit Ekstrakurikuler
                </div>
                <div class="card-body">
                    <!-- Form untuk mengedit data ekstrakurikuler -->
                    <form action="proses-ekstrakurikuler.php" method="POST" enctype="multipart/form-data">
                        <!-- Input tersembunyi untuk menyimpan ID ekstrakurikuler -->
                        <input type="hidden" name="id" value="<?php echo $ekstrakurikuler['id']; ?>">
                        <div class="mb-3">
                            <!-- Label dan input untuk Judul Ekstrakurikuler -->
                            <label for="title" class="form-label">Judul Ekstrakurikuler</label>
                            <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($ekstrakurikuler['title']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Deskripsi</label>
                            <textarea class="form-control" id="description" name="description" rows="3" required><?php echo htmlspecialchars($ekstrakurikuler['description']); ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="image" class="form-label">Gambar</label>
                            <input type="file" class="form-control" id="image" name="image" accept=".jpg, .jpeg, .png">
                            <small class="form-text text-muted">Kosongkan jika tidak ingin mengganti gambar.</small>
                        </div>
                        <button type="submit" class="btn btn-success">Simpan</button>
                        <a href="ekstrakurikuler.php" class="btn btn-secondary">Kembali</a>
                    </form>
                </div>
            </div>
        </div>
    </main>


<?php require_once "../template/footer.php"; ?>
