<?php
session_start();

// Mengecek apakah pengguna sudah login
if (!isset($_SESSION['ssLogin'])) {
    header("location:../auth/login.php");
    exit();
}

// Menghubungkan ke file konfigurasi untuk koneksi database
require_once "../config.php";
require_once "proses-ekstrakurikuler.php";

// Menetapkan judul halaman
$title = "Ekstrakurikuler - Politeknik LP3I";
// Menghubungkan header, navbar, dan sidebar
require_once "../template/header.php";
require_once "../template/navbar.php";
require_once "../template/sidebar.php";

// Mengambil data ekstrakurikuler dari database
$extracurriculars = getExtracurriculars();
?>

<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Ekstrakurikuler</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                <li class="breadcrumb-item active">Ekstrakurikuler</li>
            </ol>
            
            <!-- Tambahkan tombol tambah ekstrakurikuler -->
            <div class="card">
                <div class="card-header">
                <!-- Judul card dengan ikon dan tombol untuk menambah ekstrakurikuler -->
                <i class="fa-solid fa-list"></i> Data Ekstrakurikuler
                <a href="<?= $main_url ?>ekstrakurikuler/add-ekstrakurikuler.php" class="btn btn-sm btn-primary float-end"><i class="fa-solid fa-plus"></i> Tambah Ekstrakurikuler</a>
                </div>
           
                <div class="row">
                     <!-- Cek apakah ada data ekstrakurikuler -->
                    <?php if ($extracurriculars): ?>
                        <?php foreach ($extracurriculars as $ekstra): ?>
                            <!-- Loop melalui data ekstrakurikuler dan tampilkan dalam card -->
                            <div class="col-lg-4 col-md-6 mb-4">
                                <div class="card h-100">
                                    <!-- Gambar ekstrakurikuler -->
                                    <img src="../asset/image/<?php echo htmlspecialchars($ekstra['image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($ekstra['title']); ?>">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo htmlspecialchars($ekstra['title']); ?></h5>
                                        <p class="card-text"><?php echo htmlspecialchars($ekstra['description']); ?></p>
                                    </div>
                                    <div class="card-footer">
                                        <a href="edit-ekstrakurikuler.php?id=<?php echo $ekstra['id']; ?>" class="btn btn-primary">Edit</a>
                                        <a href="proses-ekstrakurikuler.php?delete=<?php echo $ekstra['id']; ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <!-- Pesan jika tidak ada data ekstrakurikuler -->
                        <p>Tidak ada data ekstrakurikuler.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

<?php require_once "../template/footer.php"; ?>
