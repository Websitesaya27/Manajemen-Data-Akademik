<?php

session_start();

// Mengecek apakah pengguna sudah login
if (!isset($_SESSION['ssLogin'])) {
    header("location:../auth/login.php");
    exit();
}

// Menghubungkan ke file konfigurasi untuk koneksi database
require_once "../config.php";

// Mengambil semua data ekstrakurikuler dari tabel
function getExtracurriculars() {
    global $koneksi;  // Mengakses variabel koneksi global
    // Menjalankan query untuk mengambil semua data dari tabel tbl_ekstrakurikuler
    $result = mysqli_query($koneksi, "SELECT * FROM tbl_ekstrakurikuler");
    // Mengembalikan hasil query sebagai array asosiatif
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

// Mengambil data ekstrakurikuler berdasarkan ID
function getExtracurricularById($id) {
    global $koneksi;
    $stmt = mysqli_prepare($koneksi, "SELECT * FROM tbl_ekstrakurikuler WHERE id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    return mysqli_fetch_assoc($result);
}

// Menyimpan data ekstrakurikuler (tambah atau update)
function saveExtracurricular($data) {
    global $koneksi;
    if ($data['id']) {
        // Jika ID ada, maka update data yang sudah ada
        $stmt = mysqli_prepare($koneksi, "UPDATE tbl_ekstrakurikuler SET title = ?, description = ?, image = ? WHERE id = ?");
        mysqli_stmt_bind_param($stmt, 'sssi', $data['title'], $data['description'], $data['image'], $data['id']);
    } else {
        // Jika ID tidak ada, maka insert data baru
        $stmt = mysqli_prepare($koneksi, "INSERT INTO tbl_ekstrakurikuler (title, description, image) VALUES (?, ?, ?)");
        mysqli_stmt_bind_param($stmt, 'sss', $data['title'], $data['description'], $data['image']);
    }
    // Menjalankan query
    mysqli_stmt_execute($stmt);
}

// Menghapus data ekstrakurikuler berdasarkan ID
function deleteExtracurricular($id) {
    global $koneksi;
    $stmt = mysqli_prepare($koneksi, "DELETE FROM tbl_ekstrakurikuler WHERE id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
}

// Memproses data POST dari form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Menyimpan data dari form ke dalam array
    $data = [
        'id' => $_POST['id'],
        'title' => $_POST['title'],
        'description' => $_POST['description'],
        'image' => $_FILES['image']['name'] ? uploadimg('proses-ekstrakurikuler.php') : $_POST['old_image']
    ];
    
    // Menyimpan atau memperbarui data ekstrakurikuler
    saveExtracurricular($data);
    header('Location: ekstrakurikuler.php');
    exit;
}

// Memproses data GET untuk menghapus ekstrakurikuler
if (isset($_GET['delete'])) {
    deleteExtracurricular($_GET['delete']);
    header('Location: ekstrakurikuler.php');
    exit;
}
?>
