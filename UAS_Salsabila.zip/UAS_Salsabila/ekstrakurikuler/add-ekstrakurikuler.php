<?php
session_start();

// Mengecek apakah pengguna sudah login
if (!isset($_SESSION['ssLogin'])) {
    header("location:../auth/login.php");
    exit();
}

// Menghubungkan ke file konfigurasi untuk koneksi database
require_once "../config.php";

// Menetapkan judul halaman
$title = "Tambah Ekstrakurikuler - Politeknik LP3I";
// Menghubungkan header, navbar, dan sidebar untuk tampilan konsisten
require_once "../template/header.php";
require_once "../template/navbar.php";
require_once "../template/sidebar.php";
?>


<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Tambah Ekstrakurikuler</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="ekstrakurikuler.php">Ekstrakurikuler</a></li>
                <li class="breadcrumb-item active">Tambah Ekstrakurikuler</li>
            </ol>

            <!-- Card untuk menampilkan form tambah ekstrakurikuler -->
            <div class="card mb-4">
                <div class="card-header">
                    Form Tambah Ekstrakurikuler
                </div>
                <div class="card-body">
                    <!-- Form untuk menambah data ekstrakurikuler -->
                    <form action="proses-ekstrakurikuler.php" method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <!-- Label dan input untuk Judul Ekstrakurikuler -->
                            <label for="title" class="form-label">Judul Ekstrakurikuler</label>
                            <input type="text" class="form-control" id="title" name="title" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Deskripsi</label>
                            <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="image" class="form-label">Gambar</label>
                            <input type="file" class="form-control" id="image" name="image" accept=".jpg, .jpeg, .png" required>
                        </div>
                        <button type="submit" class="btn btn-success">Tambah</button>
                        <a href="ekstrakurikuler.php" class="btn btn-secondary">Kembali</a>
                    </form>
                </div>
            </div>
        </div>
    </main>

<?php require_once "../template/footer.php"; ?>
