<?php

// Memulai sesi
session_start();

// Menghapus semua variabel sesi
session_unset();

// Mengosongkan array sesi
$_SESSION = [];

// Mengarahkan pengguna kembali ke halaman login
header("location: login.php");
exit;

?>