<?php

// Menghubungkan ke file konfigurasi untuk koneksi database
require_once "../config.php";

// Memulai sesi
session_start();

// jika tombol login ditekan
if (isset($_POST['login'])) {
    // Mengambil dan membersihkan input dari formulir
    $username = htmlspecialchars($_POST['username']);
    $password = htmlspecialchars($_POST['password']);

    // Mengecek keberadaan username dalam database
    $result = mysqli_query($koneksi, "SELECT * FROM tbl_user WHERE username = '$username'");

    //cek username
    if (mysqli_num_rows($result) === 1) {
        $row =  mysqli_fetch_assoc($result);
        // Verifikasi password
        if (password_verify($password, $row["password"])) {
            $_SESSION["ssLogin"] = true;
            $_SESSION["ssUser"] = $username;
            header("location:../index.php");
            exit;
        } else {
            // Jika password salah, tampilkan pesan kesalahan dan alihkan kembali ke halaman login
            echo "<script>
            alert('password salah..');
            document.location.href= 'login.php';
            </script>";
        }
    } else {
        // Jika username tidak terdaftar, tampilkan pesan kesalahan dan alihkan kembali ke halaman login
        echo "<script>
        alert('username tidak terdaftar..');
        document.location.href= 'login.php';
        </script>";
    }
}
?>