<?php

session_start();

// Mengecek apakah pengguna sudah login
if (!isset($_SESSION["ssLogin"])) {
    header("location: ../auth/login.php");
    exit;
}

require_once "../config.php";

// Jika tombol simpan ditekan
if (isset($_POST['simpan'])) {
    // Ambil value yang diposting
    $id         = $_POST['id'];
    $nama       = trim(htmlspecialchars($_POST['nama']));
    $email      = trim(htmlspecialchars($_POST['email']));
    $status     = $_POST['status'];
    $akreditasi = $_POST['akreditasi'];
    $alamat     = trim(htmlspecialchars($_POST['alamat']));
    $visimisi   = trim(htmlspecialchars($_POST['visimisi']));
    $gbr        = trim(htmlspecialchars($_POST['gbrLama']));

    // Cek apakah gambar baru diupload
    if ($_FILES['image']['error'] === 4) {
        // Jika tidak ada gambar baru, gunakan gambar lama
        $gbrKampus = $gbr;
    } else {
        // Upload gambar baru
        $url = 'profile-sekolah.php';
        $gbrKampus = uploadimg($url);
        @unlink('../asset/image/' . $gbr);
    }

    // Update data kampus di database
    mysqli_query($koneksi, "UPDATE tbl_kampus SET 
                            nama = '$nama',
                            email = '$email',
                            status = '$status',
                            akreditasi = '$akreditasi',
                            alamat = '$alamat',
                            visimisi = '$visimisi',
                            gambar = '$gbrKampus'
                            WHERE id = $id
                            ");
    // Arahkan ke halaman profil dengan pesan 'updated'
    header("location:profile-sekolah.php?msg=updated");
    return;                   
}

?>
