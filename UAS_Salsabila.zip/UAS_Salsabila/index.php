<?php

// Memulai sesi PHP untuk melacak status login pengguna
session_start();

// Memeriksa apakah pengguna sudah login; jika tidak, arahkan ke halaman login
if (!isset($_SESSION["ssLogin"])) {
    header("location:auth/login.php");
    exit;
}

// Menghubungkan ke file konfigurasi yang berisi pengaturan database
require_once "config.php";

// Menetapkan judul halaman
$title = "Dashboard - Politeknik LP3I";
// Memuat header dari template
require_once "template/header.php";
// Memuat navbar dari template
require_once "template/navbar.php";
// Memuat sidebar dari template
require_once "template/sidebar.php";

?>

<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4"></h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"></li>
            </ol>
            <div class="card mb-4">
                <div class="card-header">
                    <!-- Judul card dengan ikon -->
                    <i class="fas fa-image me-1"></i>
                    Politeknik LP3I
                </div>
                <div class="card-body p-0">
                    <!-- Gambar yang ditampilkan di dalam card -->
                    <img src="img2.jpg" class="img-fluid w-100" alt="...">
                </div>
            </div>
        </div>
    </main>


<?php
// Memuat footer dari template
require_once "template/footer.php";

?>
