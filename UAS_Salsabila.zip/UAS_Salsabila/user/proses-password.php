<?php

session_start();

if (!isset($_SESSION['ssLogin'])) {
    header("location: ../auth/login.php");
    exit;
}

require_once "../config.php";

if (isset($_POST['simpan'])) {
    $curPass = trim(htmlspecialchars($_POST['curPass']));
    $newPass = trim(htmlspecialchars($_POST['newPass']));
    $confPass = trim(htmlspecialchars($_POST['confPass']));

    $userName = $_SESSION['ssUser'];
    
    // Query untuk mendapatkan data user berdasarkan username
    $stmt = mysqli_prepare($koneksi, "SELECT * FROM tbl_user WHERE username = ?");
    mysqli_stmt_bind_param($stmt, 's', $userName);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $data = mysqli_fetch_array($result);
    
    // Memeriksa apakah password baru dan konfirmasi password sesuai
    if ($newPass !== $confPass) {
        header("location:password.php?msg=err1");
        exit;
    }
    
    // Memeriksa apakah password lama sesuai dengan yang ada di database
    if (!password_verify($curPass, $data['password'])) {
        header("location:password.php?msg=err2");
        exit;
    }
    
    // Meng-hash password baru dan memperbarui password di database
    $newPassHashed = password_hash($newPass, PASSWORD_DEFAULT);
    $stmt = mysqli_prepare($koneksi, "UPDATE tbl_user SET password = ? WHERE username = ?");
    mysqli_stmt_bind_param($stmt, 'ss', $newPassHashed, $userName);
    mysqli_stmt_execute($stmt);
    
    header("location:password.php?msg=updated");
    exit;
}

?>
